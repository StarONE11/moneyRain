package com.example.mydelete;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private EditText money;
    private Button gagner;
    private int solde =0;
    private TextView ok;
    private View black;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable( new ColorDrawable(getResources().getColor(R.color.teal_700)));


        money = findViewById(R.id.editTextTextPersonName);
        gagner =findViewById(R.id.button);
        ok= findViewById(R.id.textView2);
        black = findViewById(R.id.view);

        gagner.setOnClickListener(view -> {


            solde += 1000;
            ok.setText("solde " + solde + "$");
            oneee();
        });




    }public void oneee() {


        if (solde >= 5000) {
            black.setBackgroundResource(R.color.yellow);
            ok.setTextColor(Color.RED);

            Toast.makeText(MainActivity.this, money.getText().toString() + " Vous êtes riche à présent  ", Toast.LENGTH_SHORT).show();

        }

        if (solde > 10000) {
            black.setBackgroundResource(R.color.purple_700);
            Toast.makeText(MainActivity.this, money.getText().toString() + " Vous venez d'atteindre le planfond des millonnaire ", Toast.LENGTH_SHORT).show();
            ok.setTextColor(Color.BLACK);

        }
    }
};



